INSTRUCCIONES DE DESPLIEGUE (rápido, lean)
1) Descarga el ZIP y descomprímelo.
2) Opciones de hosting (gratis & profesional):
   - Netlify: arrastra la carpeta 'elite_climate_site' al panel de Netlify y publica. (Recomendado: Netlify)
   - GitHub Pages: sube al repositorio y activa Pages desde Settings -> Pages.
3) Reemplaza en index.html:
   - Telephone, email, url, logo path y 'your-id' del formspree por tus datos reales.
4) Dominio: compra en Namecheap/Google Domains y apunta DNS a Netlify/GitHub Pages.
5) Formularios: crea un endpoint en Formspree o usa Netlify Forms.
6) Cambia las imágenes en 'assets' por fotos reales del equipo para apariencia 'million-dollar'.
7) Si quieres, pídeme que personalice copy y logo con tu nombre: hago la versión final al toque.

NOTAS:
- El sitio es 100% estático y listo para producción.
- Archivos incluidos: index.html, styles.css, script.js, assets/logo.png, assets/hero-ac.jpg, README.txt
